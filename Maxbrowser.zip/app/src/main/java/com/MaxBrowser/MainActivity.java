package com.MaxBrowser;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private String url = "";
	
	private TextView textview1;
	private EditText edittext1;
	private WebView webview1;
	private TextView textview2;
	private Button button3;
	private Button button1;
	
	private TimerTask peq;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		textview1 = findViewById(R.id.textview1);
		edittext1 = findViewById(R.id.edittext1);
		webview1 = findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		textview2 = findViewById(R.id.textview2);
		button3 = findViewById(R.id.button3);
		button1 = findViewById(R.id.button1);
		
		edittext1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				peq = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								url = _charSeq;
								textview1.setVisibility(View.GONE);
								for(int _repeat17 = 0; _repeat17 < (int)(22); _repeat17++) {
									webview1.loadUrl("https://Duckduckgo.com/?q=".concat(url));
								}
							}
						});
					}
				};
				_timer.schedule(peq, (int)(2000));
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				textview2.setText(_url);
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				textview2.setText(_url);
				super.onPageFinished(_param1, _param2);
			}
		});
		
		textview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.setWebViewClient(new WebViewClient() {
					    @Override
					    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
						        String url = request.getUrl().toString();
						        if (isAdUrl(url)) {
							            // Блокируем рекламу, возвращая пустой ответ
							            return new WebResourceResponse("text/plain", "utf-8", null);
							        }
						        return super.shouldInterceptRequest(view, request);
						    }
					
					    private boolean isAdUrl(String url) {
						        return url.contains("doubleclick.net") || 
						               url.contains("ads.google.com") ||
						               url.contains("adservice.google.com") ||
						               url.contains("googlesyndication.com") ||
						               url.contains("facebook.com/ad") ||
						               url.contains("adroll.com") ||
						               url.contains("servebom.com") ||
						               url.contains("bidswitch.net") ||
						               url.contains("criteo.com") ||
						               url.contains("pubmatic.com") ||
						               url.contains("rubiconproject.com") ||
						               url.contains("imrworldwide.com") ||
						               url.contains("openx.net") ||
						               url.contains("adtech.de") ||
						               url.contains("media.net") ||
						               url.contains("yieldmanager.com") ||
						               url.contains("outbrain.com");
						    }
				});
				webview1.setWebViewClient(new WebViewClient() {
					    @Override
					    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
						        String url = request.getUrl().toString();
						        if (isTracker(url)) {
							            // Блокируем трекер, возвращая пустой ответ
							            return new WebResourceResponse("text/plain", "utf-8", null);
							        }
						        return super.shouldInterceptRequest(view, request);
						    }
					
					    private boolean isTracker(String url) {
						        // Список популярных трекеров
						        String[] trackers = {
							            "doubleclick.net", "google-analytics.com", "facebook.com", "adservice.google.com",
							            "googlesyndication.com", "analytics.yahoo.com", "scorecardresearch.com", "quantserve.com",
							            "taboola.com", "outbrain.com", "criteo.com", "rubiconproject.com", "openx.net",
							            "adnxs.com", "adsrvr.org", "adform.net", "adroll.com", "serving-sys.com",
							            "adtech.de", "advertising.com", "adblade.com", "adroll.com", "adserver.yahoo.com",
							            "ads.yahoo.com", "adsafeprotected.com", "adsrvr.org", "adtechus.com", "aduptech.com",
							            "adzerk.net", "aol.com", "appnexus.com", "bidswitch.net", "bluekai.com",
							            "casalemedia.com", "criteo.net", "exelator.com", "flashtalking.com", "gumgum.com",
							            "indexww.com", "invitemedia.com", "krxd.net", "liveramp.com", "lotame.com",
							            "media.net", "moatads.com", "nielsen.com", "openx.com", "pubmatic.com",
							            "pulse360.com", "rubiconproject.com", "sovrn.com", "spotxchange.com", "thetradedesk.com",
							            "turn.com", "valueclick.net", "yieldmo.com", "zedo.com", "ziffdavis.com"
							        };
						        for (String tracker : trackers) {
							            if (url.contains(tracker)) {
								                return true;
								            }
							        }
						        return false;
						    }
				});
				CookieManager cookieManager = CookieManager.getInstance();
				cookieManager.setAcceptCookie(false);
				SketchwareUtil.showMessage(getApplicationContext(), "Alr, Ads now are blocked! Most ads will be blocked, including google ads, facebook ads and etc, But it may not block some ads. trackers and cookies will be blocked.");
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.getSettings().setJavaScriptEnabled(false);
				SketchwareUtil.showMessage(getApplicationContext(), "Java script is disabled, Some Websites can lose functionability, To enable js you need to restart browser.");
			}
		});
	}
	
	private void initializeLogic() {
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		webview1.clearHistory();
		webview1.clearCache(true);
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}